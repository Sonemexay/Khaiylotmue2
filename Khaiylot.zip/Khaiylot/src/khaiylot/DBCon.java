/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package khaiylot;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
/**
 *
 * @author Lemon
 */
public class DBCon {
    public static java.sql.Connection mycon(){
    Connection con = null;
    try{
        Class.forName("com.mysql.cj.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db_khaiylotmue2","root","L78334497");
    }catch(SQLException e){
    }catch(ClassNotFoundException ex){
    System.out.print(ex);
    }
    return null;
    }
}
