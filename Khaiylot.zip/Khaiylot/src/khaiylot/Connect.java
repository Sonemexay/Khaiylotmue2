/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package khaiylot;
import java.sql.Connection;
import java.sql.DriverManager;
/**
 *
 * @author Lemon
 */
public class Connect {

    public static void main(String[] args) {
        Connection conn = null;

        try {
            String userName = "root";
            String password = "L78334497";

            String url = "jdbc:mysql://localhost:3306/db_khaiylotmue2";
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            conn = DriverManager.getConnection(url, userName, password);
            System.out.println("Database connection established");
        } catch (Exception e) {
            System.err.println("Cannot connect to database server");
            System.err.println(e.getMessage());
            e.printStackTrace();
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                    System.out.println("Database Connection Terminated");
                } catch (Exception e) {}
            }
        }
    }
}
